<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class BookFactory extends Factory
{
    public function definition(): array
    {
        return [
            'title'  => fake()->name(),
            'author' => fake()->name(),
            'year'   => fake()->randomElement([2000, 2001, 2002]),
        ];
    }
}