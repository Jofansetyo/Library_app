<?php

use Illuminate\Support\Facades\Route;
use App\Models\Book;
use Illuminate\Http\Request;
use App\Http\Controllers\BookController;
use App\Http\Controllers\BorrowerController;
use App\Http\Controllers\BorrowingController;

Route::get('/book', [BookController::class, 'index'])->name('books.index');

/*
|--------------------------------------------------------------------------
| FIX DI SINI (plural biar konsisten)
|--------------------------------------------------------------------------
*/
Route::get('/borrowers', [BorrowerController::class, 'index'])->name('borrowers.index');
Route::get('/borrowings', [BorrowingController::class, 'index'])->name('borrowings.index');

/*
|--------------------------------------------------------------------------
| TAMBAHAN BORROWER (CRUD)
|--------------------------------------------------------------------------
*/
Route::get('/borrowers/create', [BorrowerController::class, 'create'])->name('borrowers.create');
Route::post('/borrowers', [BorrowerController::class, 'store'])->name('borrowers.store');
Route::get('/borrowers/{id}/edit', [BorrowerController::class, 'edit'])->name('borrowers.edit');
Route::put('/borrowers/{id}', [BorrowerController::class, 'update'])->name('borrowers.update');
Route::delete('/borrowers/{id}', [BorrowerController::class, 'destroy'])->name('borrowers.destroy');

/*
|--------------------------------------------------------------------------
| TAMBAHAN BORROWING (CRUD)
|--------------------------------------------------------------------------
*/
Route::get('/borrowings/create', [BorrowingController::class, 'create'])->name('borrowings.create');
Route::post('/borrowings', [BorrowingController::class, 'store'])->name('borrowings.store');
Route::get('/borrowings/{id}/edit', [BorrowingController::class, 'edit'])->name('borrowings.edit');
Route::put('/borrowings/{id}', [BorrowingController::class, 'update'])->name('borrowings.update');
Route::delete('/borrowings/{id}', [BorrowingController::class, 'destroy'])->name('borrowings.destroy');

Route::get('/greeting', function () {
    return 'Hello World';
});

Route::get('/book/{id}', function (string $id) {
    return 'Book Id: '.$id;
});

Route::get('/book-title/{title?}', function (?string $title = 'Bumi Manusia') {
    return 'Book title: '.$title;
});

Route::get('/book-profile', function () {
    return 'Book Profile Page';
})->name('book-profile');

Route::prefix('admin')->group(function () {
    Route::get('/books', function () {
        return 'Semua buku dari halaman admin';
    });
    Route::get('/authors', function () {
        return 'Semua author dari halaman admin';
    });
});

Route::get('/book-simple', function () {
    return view('book_simple', ['title' => 'Bumi Manusia']);
});

Route::get('/books', function () {
    $books = Book::all();
    return view('books.index', ['books' => $books]);
})->name('books.index');

Route::get('/books/create', function () {
    return view('books.create');
})->name('books.create');

Route::post('/books', function (Request $request) {
    $validatedData = $request->validate([
        'title'  => 'required',
        'author' => 'required',
        'year'   => 'required|numeric',
    ]);

    $book = new Book();
    $book->title  = $validatedData['title'];
    $book->author = $validatedData['author'];
    $book->year   = $validatedData['year'];
    $book->save();

    return redirect()->route('books.index');
})->name('books.store');

Route::get('/books/{id}/edit', function ($id) {
    $book = Book::findOrFail($id);
    return view('books.edit', ['book' => $book]);
})->name('books.edit');

Route::put('/books/{id}', function (Request $request, $id) {
    $validatedData = $request->validate([
        'title'  => 'required',
        'author' => 'required',
        'year'   => 'required|numeric',
    ]);

    $book = Book::findOrFail($id);
    $book->title  = $validatedData['title'];
    $book->author = $validatedData['author'];
    $book->year   = $validatedData['year'];
    $book->save();

    return redirect()->route('books.index');
})->name('books.update');

Route::delete('/books/{id}', function ($id) {
    $book = Book::findOrFail($id);
    $book->delete();

    return redirect()->route('books.index');
})->name('books.destroy');